﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using System.Diagnostics;

namespace InsightService.Controllers
{
    [ApiController]
    [Route("api/devices")]
    public class DeviceController : ControllerBase
    {
        [HttpGet("status")]
        public IActionResult GetStatus()
        {
            return Ok(new { Status = "Service is running" });
        }

        [HttpPost("command")]
        public IActionResult ExecuteCommand([FromBody] CommandRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Command))
            {
                return BadRequest(new { Error = "Command cannot be empty" });
            }

            var result = ExecuteParticleCommand(request.Command);

            return result.StartsWith("Error:")
                ? BadRequest(new { Error = result })
                : Ok(new { Message = "Command Executed", Output = result });
        }

        private string ExecuteParticleCommand(string command)        
        {
            try
            {
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "particle", // Ensure 'particle' CLI is in the system PATH
                        Arguments = command,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };

                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                return string.IsNullOrEmpty(error) ? output : $"Error: {error}";
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        private static readonly ConcurrentQueue<string> ArduinoDataQueue = new();

        [HttpPost("arduino")]
        public IActionResult ReceiveArduinoData(string data)
        {
            ArduinoDataQueue.Enqueue(data);
            return Ok(new { message = "Data received" });
        }

        [HttpGet("arduino")]
        public IActionResult GetArduinoData()
        {
            if (ArduinoDataQueue.TryDequeue(out var data))
            {
                return Ok(new { data });
            }
            return NoContent();
        }
    }

    public record CommandRequest(string Command);
}

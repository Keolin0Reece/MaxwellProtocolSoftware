using InsightService.Controllers;
using InsightService;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Add CORS policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
        policy.WithOrigins("http://localhost:3000") // Allow requests from your frontend
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials()); // Important if credentials or SignalR WebSockets are used
});

// Add controller services
builder.Services.AddControllers(); // Enables controller routes
builder.WebHost.UseUrls("http://0.0.0.0:5000");
// Add SignalR
builder.Services.AddSignalR();

// Add hosted service and dependencies
builder.Services.AddHostedService<Worker>();
builder.Services.AddSingleton<DeviceController>(); // Ensure this is scoped correctly

var app = builder.Build();

// Use CORS middleware before routing
app.UseCors("AllowFrontend");

app.UseRouting();

app.MapControllers(); // Map controller routes
app.MapHub<ArduinoHub>("/arduinoHub"); // Map SignalR hub

app.Run();

using InsightService;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System.Globalization;
using System.IO.Ports;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IHubContext<ArduinoHub> _hubContext;
    private readonly SerialPort _serialPort;
    private readonly List<List<(double Latitude, double Longitude)>> _polygons;
    private readonly int[] _currentPointIndices; // Track the current index for each polygon

    public Worker(ILogger<Worker> logger, IHubContext<ArduinoHub> hubContext)
    {
        _logger = logger;
        _hubContext = hubContext;

        _serialPort = new SerialPort("COM5", 9500)
        {
            NewLine = "\r\n",
            ReadTimeout = 3000,
            BaudRate = 9600,
            PortName = "COM5",
            DataBits = 8,
            Parity = Parity.None,
            StopBits = StopBits.One,
            Handshake = Handshake.None,
            WriteTimeout = 5000
        };

        // Load polygons from CSV
        _polygons = LoadPolygons(@"C:\\Users\\stlid\\Downloads\\Travel- Untitled layer.csv");
        _currentPointIndices = new int[_polygons.Count]; // Initialize tracking indices
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Attach event handler for serial port data
        _serialPort.DataReceived += async (sender, e) =>
        {
            try
            {
                var data = _serialPort.ReadExisting().Trim(); // Reads and trims all available data
                _logger.LogInformation("Arduino Data: {Data}", data);

                if (data == "A" || data == "B")
                {
                    await HandleArduinoSignal(data);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error reading data from serial port: {Message}", ex.Message);
            }
        };

        try
        {
            _serialPort.Open();
            _logger.LogInformation("Serial port opened. Listening for Arduino data...");
        }
        catch (Exception ex)
        {
            _logger.LogError("Error opening serial port: {Message}", ex.Message);
        }

        while (!stoppingToken.IsCancellationRequested)
        {
            if (_polygons.Count > 0)
            {
                for (int i = 0; i < _polygons.Count; i++)
                {
                    // Get the current polygon and point
                    var currentPolygon = _polygons[i];
                    var currentPointIndex = _currentPointIndices[i];
                    var currentPoint = currentPolygon[currentPointIndex];

                    // Send GPS coordinates
                    var gpsData = new
                    {
                        Id = i + 1, // Assign unique ID for each polygon
                        Latitude = currentPoint.Latitude,
                        Longitude = currentPoint.Longitude
                    };

                    await _hubContext.Clients.All.SendAsync("ReceiveGPSData", gpsData);

                    _logger.LogInformation("Sent GPS Data: {Latitude}, {Longitude} for Polygon {Id}",
                        currentPoint.Latitude, currentPoint.Longitude, gpsData.Id);

                    // Move to the next point in the polygon
                    _currentPointIndices[i] = (currentPointIndex + 1) % currentPolygon.Count;
                }
            }
            else
            {
                _logger.LogWarning("No polygons loaded. Cannot generate GPS coordinates.");
            }

            await Task.Delay(2000, stoppingToken); // Send updates every 2 seconds
        }
    }

    private async Task HandleArduinoSignal(string signal)
    {
        if (signal == "A")
        {
            _logger.LogInformation("Received signal: A");
            await _hubContext.Clients.All.SendAsync("ReceiveSignal", new { Signal = "A" });
        }
        else if (signal == "B")
        {
            _logger.LogInformation("Received signal: B");
            await _hubContext.Clients.All.SendAsync("ReceiveSignal", new { Signal = "B" });
        }
    }

    private List<List<(double Latitude, double Longitude)>> LoadPolygons(string filePath)
    {
        var polygons = new List<List<(double Latitude, double Longitude)>>();

        try
        {
            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                var trimmedLine = line.Trim();

                // Skip header or invalid lines
                if (trimmedLine.StartsWith("WKT") || string.IsNullOrWhiteSpace(trimmedLine))
                {
                    _logger.LogWarning("Skipping invalid line: {Line}", trimmedLine);
                    continue;
                }

                // Extract polygon coordinates from WKT
                if (trimmedLine.StartsWith("\"POLYGON"))
                {
                    var startIndex = trimmedLine.IndexOf("((") + 2;
                    var endIndex = trimmedLine.IndexOf("))");
                    var coordinateString = trimmedLine.Substring(startIndex, endIndex - startIndex);

                    var points = coordinateString.Split(',')
                        .Select(point => point.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries))
                        .Select(coords => (
                            Latitude: double.Parse(coords[1], CultureInfo.InvariantCulture),
                            Longitude: double.Parse(coords[0], CultureInfo.InvariantCulture)))
                        .ToList();

                    polygons.Add(points);
                }
            }

            _logger.LogInformation("Polygons loaded successfully from {FilePath}", filePath);
        }
        catch (Exception ex)
        {
            _logger.LogError("Error loading polygons from CSV: {Message}", ex.Message);
        }

        return polygons;
    }

    public override void Dispose()
    {
        if (_serialPort.IsOpen)
        {
            _serialPort.Close();
        }
        _serialPort.Dispose();
        base.Dispose();
    }
}
